<?php
// created: 2012-03-22 22:24:10
$dictionary["Meeting"]["fields"]["pos_sponsors_activities_meetings"] = array (
  'name' => 'pos_sponsors_activities_meetings',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_MEETINGS_FROM_POS_SPONSORS_TITLE',
);
