<?php
// created: 2012-03-22 22:24:10
$dictionary["Task"]["fields"]["pos_sponsorcontacts_activities_tasks"] = array (
  'name' => 'pos_sponsorcontacts_activities_tasks',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_TASKS_FROM_POS_SPONSORCONTACTS_TITLE',
);
