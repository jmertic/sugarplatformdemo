<?php
// created: 2012-03-22 22:24:10
$dictionary["Meeting"]["fields"]["pos_sponsorcontacts_activities_meetings"] = array (
  'name' => 'pos_sponsorcontacts_activities_meetings',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_MEETINGS_FROM_POS_SPONSORCONTACTS_TITLE',
);
