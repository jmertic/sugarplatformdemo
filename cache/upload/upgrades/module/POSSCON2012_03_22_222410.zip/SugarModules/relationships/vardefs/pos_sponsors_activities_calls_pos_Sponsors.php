<?php
// created: 2012-03-22 22:24:10
$dictionary["pos_Sponsors"]["fields"]["pos_sponsors_activities_calls"] = array (
  'name' => 'pos_sponsors_activities_calls',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
