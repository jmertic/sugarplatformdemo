<?php
// created: 2012-03-22 22:24:10
$dictionary["pos_Speakers"]["fields"]["pos_speakers_activities_calls"] = array (
  'name' => 'pos_speakers_activities_calls',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
