<?php
// created: 2012-03-22 22:24:10
$dictionary["Call"]["fields"]["pos_sponsorcontacts_activities_calls"] = array (
  'name' => 'pos_sponsorcontacts_activities_calls',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_CALLS_FROM_POS_SPONSORCONTACTS_TITLE',
);
