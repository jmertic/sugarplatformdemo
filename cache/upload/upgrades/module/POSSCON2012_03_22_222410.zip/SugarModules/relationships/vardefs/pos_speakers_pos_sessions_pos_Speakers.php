<?php
// created: 2012-03-22 22:24:10
$dictionary["pos_Speakers"]["fields"]["pos_speakers_pos_sessions"] = array (
  'name' => 'pos_speakers_pos_sessions',
  'type' => 'link',
  'relationship' => 'pos_speakers_pos_sessions',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_POS_SPEAKERS_POS_SESSIONS_FROM_POS_SESSIONS_TITLE',
);
