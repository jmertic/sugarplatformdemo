<?php
// created: 2012-03-22 22:24:10
$dictionary["Email"]["fields"]["pos_speakers_activities_emails"] = array (
  'name' => 'pos_speakers_activities_emails',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_EMAILS_FROM_POS_SPEAKERS_TITLE',
);
