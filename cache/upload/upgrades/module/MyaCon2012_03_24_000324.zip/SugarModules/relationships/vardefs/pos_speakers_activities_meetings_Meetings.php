<?php
// created: 2012-03-24 00:03:24
$dictionary["Meeting"]["fields"]["pos_speakers_activities_meetings"] = array (
  'name' => 'pos_speakers_activities_meetings',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_MEETINGS_FROM_POS_SPEAKERS_TITLE',
);
