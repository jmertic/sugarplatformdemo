<?php
// created: 2012-03-24 00:03:24
$dictionary["pos_Sessions"]["fields"]["pos_sessions_pos_events"] = array (
  'name' => 'pos_sessions_pos_events',
  'type' => 'link',
  'relationship' => 'pos_sessions_pos_events',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SESSIONS_POS_EVENTS_FROM_POS_EVENTS_TITLE',
);
