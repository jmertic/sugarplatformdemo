<?php
// created: 2012-03-24 00:03:24
$dictionary["pos_SponsorContacts"]["fields"]["pos_sponsorcontacts_activities_meetings"] = array (
  'name' => 'pos_sponsorcontacts_activities_meetings',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
