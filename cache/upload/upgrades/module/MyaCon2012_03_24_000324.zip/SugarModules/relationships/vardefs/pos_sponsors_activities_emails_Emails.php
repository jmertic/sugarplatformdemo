<?php
// created: 2012-03-24 00:03:24
$dictionary["Email"]["fields"]["pos_sponsors_activities_emails"] = array (
  'name' => 'pos_sponsors_activities_emails',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_EMAILS_FROM_POS_SPONSORS_TITLE',
);
