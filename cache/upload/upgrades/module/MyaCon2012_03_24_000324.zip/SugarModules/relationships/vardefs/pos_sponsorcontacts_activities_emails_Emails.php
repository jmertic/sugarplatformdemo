<?php
// created: 2012-03-24 00:03:24
$dictionary["Email"]["fields"]["pos_sponsorcontacts_activities_emails"] = array (
  'name' => 'pos_sponsorcontacts_activities_emails',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_EMAILS_FROM_POS_SPONSORCONTACTS_TITLE',
);
