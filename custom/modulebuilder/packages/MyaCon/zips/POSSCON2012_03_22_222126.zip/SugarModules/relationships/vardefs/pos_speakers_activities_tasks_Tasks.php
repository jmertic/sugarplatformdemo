<?php
// created: 2012-03-22 22:21:25
$dictionary["Task"]["fields"]["pos_speakers_activities_tasks"] = array (
  'name' => 'pos_speakers_activities_tasks',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_TASKS_FROM_POS_SPEAKERS_TITLE',
);
