<?php
// created: 2011-03-17 16:00:24
$layout_defs["pos_Sponsorships"]["subpanel_setup"]["pos_sponsors_sponsorships"] = array (
  'order' => 100,
  'module' => 'pos_Sponsors',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_POS_SPONSORS_POS_SPONSORSHIPS_FROM_POS_SPONSORS_TITLE',
  'get_subpanel_data' => 'pos_sponsors_sponsorships',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
<?php
// created: 2011-03-17 16:06:44
$layout_defs["pos_Sponsorships"]["subpanel_setup"]["pos_sponsors_sponsorships"] = array (
  'order' => 100,
  'module' => 'pos_Sponsors',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_POS_SPONSORS_POS_SPONSORSHIPS_FROM_POS_SPONSORS_TITLE',
  'get_subpanel_data' => 'pos_sponsors_sponsorships',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
?>
