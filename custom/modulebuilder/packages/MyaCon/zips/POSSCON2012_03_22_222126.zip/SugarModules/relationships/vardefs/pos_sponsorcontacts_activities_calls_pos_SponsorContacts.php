<?php
// created: 2012-03-22 22:21:25
$dictionary["pos_SponsorContacts"]["fields"]["pos_sponsorcontacts_activities_calls"] = array (
  'name' => 'pos_sponsorcontacts_activities_calls',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_calls',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_CALLS_FROM_CALLS_TITLE',
);
