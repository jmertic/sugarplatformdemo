<?php
// created: 2012-03-22 22:21:25
$dictionary["Note"]["fields"]["pos_sponsorcontacts_activities_notes"] = array (
  'name' => 'pos_sponsorcontacts_activities_notes',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_notes',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_NOTES_FROM_POS_SPONSORCONTACTS_TITLE',
);
