<?php
// created: 2012-03-22 22:21:18
$dictionary["pos_Speakers"]["fields"]["pos_speakers_activities_notes"] = array (
  'name' => 'pos_speakers_activities_notes',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_notes',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
