<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$app_list_strings['parent_type_display']['pos_Sponsors'] = 'Pos_Sponsors';
$app_list_strings['record_type_display']['pos_Sponsors'] = 'Pos_Sponsors';
$app_list_strings['record_type_display_notes']['pos_Sponsors'] = 'Pos_Sponsors';
