<?php
// created: 2012-03-22 22:21:18
$dictionary["pos_SponsorContacts"]["fields"]["pos_sponsorcontacts_activities_emails"] = array (
  'name' => 'pos_sponsorcontacts_activities_emails',
  'type' => 'link',
  'relationship' => 'pos_sponsorcontacts_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORCONTACTS_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
