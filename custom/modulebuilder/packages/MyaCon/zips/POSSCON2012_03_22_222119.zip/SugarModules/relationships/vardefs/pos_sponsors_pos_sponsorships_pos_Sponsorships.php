<?php
// created: 2011-03-17 16:06:44
$dictionary["pos_Sponsorships"]["fields"]["pos_sponsors_sponsorships"] = array (
  'name' => 'pos_sponsors_sponsorships',
  'type' => 'link',
  'relationship' => 'pos_sponsors_pos_sponsorships',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_POS_SPONSORSHIPS_FROM_POS_SPONSORS_TITLE',
);
