<?php
// created: 2012-03-22 22:21:19
$dictionary["Task"]["fields"]["pos_sponsors_activities_tasks"] = array (
  'name' => 'pos_sponsors_activities_tasks',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_tasks',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_TASKS_FROM_POS_SPONSORS_TITLE',
);
