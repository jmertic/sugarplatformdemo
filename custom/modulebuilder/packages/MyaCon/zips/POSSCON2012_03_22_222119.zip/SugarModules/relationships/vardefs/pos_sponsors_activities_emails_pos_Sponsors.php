<?php
// created: 2012-03-22 22:21:19
$dictionary["pos_Sponsors"]["fields"]["pos_sponsors_activities_emails"] = array (
  'name' => 'pos_sponsors_activities_emails',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_emails',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_EMAILS_FROM_EMAILS_TITLE',
);
