<?php
// created: 2012-03-22 22:21:19
$dictionary["pos_Sponsors"]["fields"]["pos_sponsors_pos_sponsorcontacts"] = array (
  'name' => 'pos_sponsors_pos_sponsorcontacts',
  'type' => 'link',
  'relationship' => 'pos_sponsors_pos_sponsorcontacts',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_POS_SPONSORS_POS_SPONSORCONTACTS_FROM_POS_SPONSORCONTACTS_TITLE',
);
