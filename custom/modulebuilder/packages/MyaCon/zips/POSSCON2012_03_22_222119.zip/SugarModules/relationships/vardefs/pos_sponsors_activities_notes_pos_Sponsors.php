<?php
// created: 2012-03-22 22:21:19
$dictionary["pos_Sponsors"]["fields"]["pos_sponsors_activities_notes"] = array (
  'name' => 'pos_sponsors_activities_notes',
  'type' => 'link',
  'relationship' => 'pos_sponsors_activities_notes',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_ACTIVITIES_NOTES_FROM_NOTES_TITLE',
);
