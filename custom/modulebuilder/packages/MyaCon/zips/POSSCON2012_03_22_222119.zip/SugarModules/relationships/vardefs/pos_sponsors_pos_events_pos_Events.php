<?php
// created: 2012-03-22 22:21:19
$dictionary["pos_Events"]["fields"]["pos_sponsors_pos_events"] = array (
  'name' => 'pos_sponsors_pos_events',
  'type' => 'link',
  'relationship' => 'pos_sponsors_pos_events',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPONSORS_POS_EVENTS_FROM_POS_SPONSORS_TITLE',
);
