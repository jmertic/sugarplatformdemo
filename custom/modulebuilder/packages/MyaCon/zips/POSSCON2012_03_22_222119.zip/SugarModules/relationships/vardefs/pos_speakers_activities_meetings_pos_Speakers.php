<?php
// created: 2012-03-22 22:21:18
$dictionary["pos_Speakers"]["fields"]["pos_speakers_activities_meetings"] = array (
  'name' => 'pos_speakers_activities_meetings',
  'type' => 'link',
  'relationship' => 'pos_speakers_activities_meetings',
  'source' => 'non-db',
  'vname' => 'LBL_POS_SPEAKERS_ACTIVITIES_MEETINGS_FROM_MEETINGS_TITLE',
);
