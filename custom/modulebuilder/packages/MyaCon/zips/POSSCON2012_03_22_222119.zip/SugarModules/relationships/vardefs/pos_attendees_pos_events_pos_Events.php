<?php
// created: 2012-03-22 22:21:18
$dictionary["pos_Events"]["fields"]["pos_attendees_pos_events"] = array (
  'name' => 'pos_attendees_pos_events',
  'type' => 'link',
  'relationship' => 'pos_attendees_pos_events',
  'source' => 'non-db',
  'vname' => 'LBL_POS_ATTENDEES_POS_EVENTS_FROM_POS_ATTENDEES_TITLE',
);
